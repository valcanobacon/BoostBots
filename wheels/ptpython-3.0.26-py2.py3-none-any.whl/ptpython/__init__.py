from __future__ import annotations

from .repl import embed

__all__ = ["embed"]
